<?php
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    session_start();
    require("../connect.php");
    
    if(isset($_SESSION["id"])){
        $id = intval($_SESSION["id"]);
        echo $id;
        $newScore = intval($_POST["score"]);

        $sql = "UPDATE user SET score = ? WHERE id = ?";
        $stmt = $kapcsolat->prepare($sql);
        $stmt->bindParam(1, $newScore, PDO::PARAM_INT);
        $stmt->bindParam(2, $id, PDO::PARAM_INT);

        if($stmt->execute())
        {
            echo "Pontszám frissítése sikeresen megtörtént!";
        }
        else{
            echo "Hiba történt: " . $stmt->errorCode() ."";
        }
    }else{
        echo "Hiba: Csak POST kérés engedélyezett";
    }
}
?>