<?php
header('Content-Type: application/json'); 

$defaultMap = "map1";

$mapName = isset($_GET['map']) ? $_GET['map'] : $defaultMap;

$filePath = "../maps/$mapName.txt";

if(file_exists($filePath))
{
    $content = file_get_contents($filePath);
    echo json_encode([
        'success' => true,
        'data' => $content
    ]);
}
else
{
    echo json_encode([
            'success' => false,
            'message' => "A $mapName pálya nem található!"
        ]);
}
?>