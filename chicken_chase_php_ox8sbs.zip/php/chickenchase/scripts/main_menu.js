export class MainMenu
{
    constructor(ctx)
    {
        this.ctx = ctx
        this.sky = this.loadImage("src/img/menu/sky.png");
        this.clouds = [this.loadImage("src/img/background/clouds1.png"), this.loadImage("src/img/background/clouds2.png"), this.loadImage("src/img/background/clouds3.png")];
        this.bottomImage = this.loadImage("src/img/menu/bottom.png");
        this.inMainMenu = true;
        this.clouds_x = [0, 320, -320];
        this.cloudTimer = 0;
        this.bottomImageX = 300;
        this.bottomImageCounter = 0;
        this.newGameButton = document.getElementById("newGame");
        this.mainMusic = new Audio("src/au/music/Future King of Heaven - Zachariah Hickman.mp3");
        this.mainMusic.loop = true;
        this.mainMusic.volume = 0.5;
        this.profileDiv = document.getElementById("profileDiv");
        this.showProfileButton = document.getElementById("profilB");
        this.backToMenuButton = document.getElementById("backtomenuB");
        this.addEvents();
    }

    loadScore()
    {
        fetch('scripts/load_score.php', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(response => response.json()).then(data => 
        {
            if(data.error)
            {
                console.error("Hiba történt: ", data.error);
            }
            else{
                const score = data.score;
            }
        }
        ).catch(error => {
            console.error("Hálozati hiba vagy szerver hiba: ", error);
        })
    }

    addEvents()
    {   
        this.newGameButton.addEventListener("click", this.startNewGame.bind(this));
        this.showProfileButton.addEventListener("click", this.showProfileData.bind(this));
        this.backToMenuButton.addEventListener("click", this.hideProfileData.bind(this));
        this.loadScore();
    }

    showProfileData()
    {
        this.profileDiv.style.display = "block";
    }

    hideProfileData()
    {
        this.profileDiv.style.display = "none";
    }

    startNewGame()
    {
        if(this.mainMusic.pause) this.mainMusic.play();
        this.inMainMenu = false;
    }

    loadImage(path)
    {
        const img = new Image();
        img.src = path;
        return img;
    }

    drawMenuBackground()
    {
        this.ctx.drawImage(this.sky, 0, 0, 640, 480);
        this.ctx.drawImage(this.clouds[0], this.clouds_x[0], 0);
        this.ctx.drawImage(this.clouds[1], this.clouds_x[1], 0);
        this.ctx.drawImage(this.clouds[2], this.clouds_x[2], 0);
        if(this.cloudTimer == 5)
        {
            if(this.clouds_x[0] > 640) this.clouds_x[0] = -320;
            if(this.clouds_x[1] > 640) this.clouds_x[1] = -320;
            if(this.clouds_x[2] > 640) this.clouds_x[2] = -320;
            ++this.clouds_x[0];
            ++this.clouds_x[1];
            ++this.clouds_x[2];
            this.cloudTimer = 0;
        }
        ++this.cloudTimer;
        if(this.bottomImageX > 0) this.bottomImageX -= 4;
        this.ctx.drawImage(this.bottomImage, 0, this.bottomImageX, 640, 480);
    }

}