<?php
session_start();

header('Content-Type: application/json; charset=utf-8');

if(!isset($_SESSION["id"]))
{
    echo json_encode(["error" => "A felhasználó nem jelentkezett be."]);
    exit();
}

require("../connect.php");

$username = $_SESSION["username"];

$stmt = $kapcsolat->prepare("SELECT score FROM user WHERE username = :username");
$stmt->execute(["username"=>$username]);

$result = $stmt->fetch(PDO::FETCH_ASSOC);

if($result)
{
    $_SESSION["score"] = $result["score"];
    echo json_encode(["score" => (int)$result["score"]]);
}else {
    echo json_encode(["error" => "A felhasználó nem található az adatbázisban."]);
}
?>