<?php
session_start();
if(isset($_SESSION["id"]) && isset($_POST["action"]))
{
    session_unset();
    session_destroy();

    header("Location: ../login.php");
    exit();
}
?>