import { Player } from "./player.js";
import { Fox } from "./enemy.js";
import { PickUp } from "./pickups.js";
import { SpawnPoint } from "./spawnpoint.js";
import { MainMenu } from "./main_menu.js";
import { TILE_SIZE, Decoration } from "./utils.js";

class Tile
{
    constructor(type, x, y)
    {
        this.x = x;
        this.y = y;
        this.type = type;
        this.width = TILE_SIZE;
        this.height = TILE_SIZE;
    }
}

class Scene
{
    constructor(map, ctx, canvas)
    {
        this.map = map;
        this.currentMap = [];
        this.tile_rects = [];
        this.jatekos = new Player(50, 0, 30, 38, 3, 2, 100, ctx, canvas);
        this.hatter = new Image();
        this.hatter.src = "src/img/background/rendes_hatter.png";
        this.clouds = [this.loadImage("src/img/background/clouds1.png"), this.loadImage("src/img/background/clouds2.png"), this.loadImage("src/img/background/clouds3.png")];
        this.clouds_x = [0, 320, -320];
        this.cloudTimer = 0;
        this.ctx = ctx;
        this.canvas = canvas;
        this.mapImages = [this.loadImage("src/img/ground/dirt.png"), this.loadImage("src/img/ground/dirt_platform.png"), this.loadImage("src/img/ground/grass.png"), this.loadImage("src/img/ground/grass_end_left.png"), this.loadImage("src/img/ground/grass_end_right.png"), this.loadImage("src/img/ground/grass_platform.png"), this.loadImage("src/img/ground/grass_platform_end_left.png"), this.loadImage("src/img/ground/grass_platform_end_right.png"), this.loadImage("src/img/ground/stoned_dirt.png")];
        this.guibackgroundImage = this.loadImage("src/img/gui/gui_hatter.png");
        this.featherImage = this.loadImage("src/img/gui/full_feather.png")
        this.missingFeatherImage = this.loadImage("src/img/gui/missing_feather.png")
        this.profilImage = this.loadImage("src/img/gui/profil.png");
        this.cornImage = this.loadImage("src/img/objects/pickups/corn.png");
        this.enemies = [];
        this.pickups = [];
        this.entities = [];
        this.spawnpoints = [new SpawnPoint(3080, 310, 52, 52, ctx)]
        this.poops = [];
        this.data = new Data(this.ctx, this.canvas);
        this.loadSpecificMap(0);
    }

    loadSpecificMap(mapId)
    {
        switch(mapId)
        {
            case 0:
                this.enemies = this.data.map_1_enemies;
                this.pickups = this.data.map_1_pickups;
                break;
            case 1:
                this.enemies = this.data.map_2_enemies;
                this.pickups = this.data.map_2_pickups;
                break;
        }
        this.entities = [this.enemies, this.pickups]
    }
    loadMap()
    {
        this.currentMap = [];
        for(let i = 0; i < this.map.length; ++i)
        {
            for(let j = 0; j < this.map[i].length; ++j)
            {
                if(this.map[i][j] != 0)
                {
                    this.currentMap.push(new Tile(this.map[i][j], j * TILE_SIZE, i * TILE_SIZE));
                }
            }
        }
    }

    loadImage(path)
    {
        const img = new Image();
        img.src = path;
        return img;
    }
    
    drawBackground()
    {
        this.ctx.drawImage(this.hatter, 0, 0);
        this.ctx.drawImage(this.clouds[0], this.clouds_x[0], 0);
        this.ctx.drawImage(this.clouds[1], this.clouds_x[1], 0);
        this.ctx.drawImage(this.clouds[2], this.clouds_x[2], 0);
        if(this.cloudTimer == 5)
        {
            if(this.clouds_x[0] > 640) this.clouds_x[0] = -320;
            if(this.clouds_x[1] > 640) this.clouds_x[1] = -320;
            if(this.clouds_x[2] > 640) this.clouds_x[2] = -320;
            ++this.clouds_x[0];
            ++this.clouds_x[1];
            ++this.clouds_x[2];
            this.cloudTimer = 0;
        }
        ++this.cloudTimer;
    }
    drawMap(scrollX, scrollY)
    {
        this.drawBackground();
        for(const tile of this.currentMap)
        {
            this.ctx.drawImage(this.mapImages[(tile.type - 1)], tile.x - scrollX, tile.y - scrollY, tile.width, tile.height);
        }
    }
    drawGUI()
    {
        this.ctx.drawImage(this.guibackgroundImage, 0, 400, 640, 80);
        this.ctx.drawImage(this.profilImage, 10, 410, 64, 64);
        for(let i = 0; i < 5; ++i) this.ctx.drawImage(this.missingFeatherImage, 90+(i*32), 440, 30, 26);
        for(let i = 0; i < (this.jatekos.health / 20); ++i) this.ctx.drawImage(this.featherImage, 90+(i*32), 440, 30, 26); 
        
        this.ctx.fillText(`x${this.jatekos.lives}`, 130, 430);
        this.ctx.fillText(`${this.jatekos.highScore}`, 620, 430);
        this.ctx.drawImage(this.cornImage, 530, 440, 27, 27);
        this.ctx.fillText(`x${this.jatekos.collectedCorns}`, 620, 460)
    }
    update(scrollX, scrollY)
    {
        for(const type of this.entities)
        {
            for(const entity of type)
            {
                entity.draw(scrollX, scrollY);
                if(entity.type == "fox") entity.update(this.jatekos.poops);
            }
        }
        for(const spawnpoint of this.spawnpoints) spawnpoint.draw(scrollX, scrollY);
        this.data.map_1_deco.draw(scrollX, scrollY);
        this.jatekos.update(this.currentMap, this.entities, this.spawnpoints, scrollX, scrollY, this.data.map_1_deco);
        for(let i = 0; i < this.entities.length; ++i)
        {
            for(let j = 0; j < this.entities[i].length; ++j)
            {
                if(this.entities[i][j].type == "collected" || this.entities[i][j].type == "dead") this.entities[i].splice(j, 1);
            }
        }
    }
}

class GameEngine
{
    constructor()
    {
        this.mainMenuCanvas = document.getElementById("mainMenuCanvas");
        this.mainMenuCtx = this.mainMenuCanvas.getContext("2d");
        this.inMainMenu = true;
        this.isGameActive = false;
        this.mainMenuDiv = document.getElementById("menuDiv");
        this.gameDiv = document.getElementById("gameDiv");
        this.canvas = document.getElementById("gameCanvas");
        this.ctx = this.canvas.getContext("2d");
        this.ctx.imageSmoothingEnabled = false;
        this.ctx.font = '18px "Press Start 2P"';
        this.ctx.fillStyle = "white";
        this.ctx.textAlign = "right";
        this.infobg = new Image();
        this.infobg.src = "src/img/gui/infobg.png";
        this.infosbg = new Image();
        this.infosbg.src = "src/img/gui/info.png";
        this.mainMenu = new MainMenu(this.mainMenuCtx);
        const defaultMaps = ["map1_d", "map2_d"];
        this.scene = undefined;
        this.initScene();
        this.mapId = 0;
        this.gameLoop = this.gameLoop.bind(this);
        this.scrollX = 0;
        this.scrollY = 0;
        this.paused = false;
        this.isGameFinished = false;
        this.outOfLives = false;
        this.infoScreen = true;
        window.addEventListener("keypress", this.handleKeys.bind(this));
        this.isRestarting = false;
        this.test_data = undefined;
        this.isSavingScore = false;
        this.pauseMenuDiv = document.getElementById("pauseDiv");
        this.backToMenuButton = document.getElementById("p_backToMenu");
        this.backToGameButton = document.getElementById("p_backToGame");
        this.addEvents();
        this.menuHighScoreText = document.getElementById("highScoreText");
    }

    addEvents()
    {
        this.backToGameButton.addEventListener("click", this.backToGame.bind(this));
        this.backToMenuButton.addEventListener("click", this.backToMenu.bind(this));
    }

    async initScene()
    {
        this.game_map = await this.processMapData();
        this.scene = new Scene(this.game_map, this.ctx, this.canvas);
        this.scene.loadMap();
    }


    mapLoadTest(map)
    {
        return fetch(`scripts/mapReader.php?map=${map}`).then(response => response.json()).then(data => {
            if(data.success)
            {
                console.log("A pálya sikeresen betöltve!");
                return data.data;
            }
            else{
                console.log("Nem lehet betölteni a pályát!", data.message);
                return null;
            }
        }).catch(error => {
            console.log("Hálozati hiba:", error);
            return null;
        });
    }

    async processMapData()
    {
        let finalData = []
        this.test_data = await this.mapLoadTest("map1_d");
        let temp_data = this.test_data.split("\n");
        finalData = temp_data.map(row => row.split(/,\s*/));
        for(let i = 0; i < finalData.length; ++i)
        {
            let temp_str = finalData[i][finalData[0].length-1];
            let final_str = temp_str.replace(/\r/g, "");
            finalData[i].pop(finalData[i][finalData[0].length-1]);
            finalData[i].push(final_str);
        }
        return finalData;
    }

    handleKeys(key)
    {
        if(key.key == "p" && this.isGameActive && !this.paused)
        {
            this.paused = true;
            this.pauseMenuDiv.style.display = "block";
        }
        if(this.infoScreen && key.key == "e") this.infoScreen = false; 
        if(this.outOfLives || this.isGameFinished)
        {
            if(key.key == "r")
            {
                this.isRestarting = true;
                this.restart();
            }
        }
    }

    loadNextMap()
    {

    }

    restart()
    {
        if(this.isRestarting)
        {
            this.isGameFinished = false;
            this.outOfLives = false;
            this.scene = new Scene(this.game_map, this.ctx, this.canvas);
            this.scene.loadMap();
        }
    }

    finishGame()
    {
        this.getScore();
    }

    test_m()
    {
        this.getScore();
    }

    getScore()
    {
        fetch('scripts/load_score.php', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(response => response.json()).then(data => 
        {
            if(data.error)
            {
                console.error("Hiba történt: ", data.error);
            }
            else{
                const score = data.score;
                if(score < this.scene.jatekos.highScore) 
                {
                    this.menuHighScoreText.textContent = `High Score: ${this.scene.jatekos.highScore}`;
                    this.updateScore(this.scene.jatekos.highScore)
                }
                else{
                    this.menuHighScoreText.textContent = `High Score: ${score}`;
                }
            }
        }
        ).catch(error => {
            console.error("Hálozati hiba vagy szerver hiba: ", error);
        })
    }

    updateScore(newScore)
    {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "scripts/save_score.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.onload = function()
        {
            if(xhr.status === 200)
            {
                console.log(xhr.responseText);
            }
            else{
                console.error("Hiba történt a frissítés során");
            }
        };

        xhr.send("score=" + encodeURIComponent(newScore));
    }

    backToMenu()
    {
        this.mainMenu.inMainMenu = true;
        this.paused = false;
        this.isGameFinished = false;
        this.outOfLives = false;
        this.infoScreen = true;
        this.inMainMenu = true;
        this.isGameActive = false;        
        this.mainMenuDiv.style.display = "block";
        this.gameDiv.style.display = "none";
        this.pauseMenuDiv.style.display = "none";
    }

    backToGame()
    {
        this.paused = false;
        this.pauseMenuDiv.style.display = "none";
    }

    gameLoop()
    {
        if(this.inMainMenu)
        {
            this.mainMenu.drawMenuBackground();
            this.inMainMenu = this.mainMenu.inMainMenu;
        }
        else
        {
                if(!this.isGameActive)
                {
                    this.isGameActive = true;
                    this.mainMenuDiv.style.display = "none";
                    this.gameDiv.style.display = "block";
                    this.isRestarting = true;
                    this.restart();
                }
                if(this.infoScreen)
                {
                    this.ctx.drawImage(this.infosbg, 0, 0, 640, 480);
                }
                else
                {
                    if(!this.paused && !this.isGameFinished && !this.outOfLives)
                        {
                            this.isSavingScore = false;
                            this.isRestarting = false;
                            this.outOfLives = this.scene.jatekos.outOfLives;
                            this.isGameFinished = this.scene.jatekos.isGameFinished;
                            this.scrollX += ((this.scene.jatekos.x - this.scrollX - this.scene.jatekos.playerScrollX) / 20.0);
                            if(this.scrollX < 0) this.scrollX = 0;
                            this.scrollX = Math.floor(this.scrollX);
                            if(!this.scene.jatekos.dying) this.scrollY += ((this.scene.jatekos.y - this.scrollY - this.scene.jatekos.playerScrollY) / 20.0);
                            if(this.scrollY < 0) this.scrollY = 0;
                            this.scrollY = Math.floor(this.scrollY);
                            this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
                            this.scene.drawMap(this.scrollX, this.scrollY);
                            
                            this.scene.update(this.scrollX, this.scrollY);
                            this.scene.drawGUI();
                        }
                        else if(this.paused && !this.isGameFinished) {}
                        else if(this.isGameFinished)
                        {
                            if(!this.isSavingScore)
                            {
                                this.isSavingScore = true;
                                this.finishGame();
                            }
                            this.ctx.drawImage(this.infobg, 0, 0, 640, 480);
                            this.ctx.fillText("Gratulálok, visszajutottál!", 550, 50);
                            this.ctx.fillText("A játék újrakezdéséhez nyomd", 560, 250);
                            this.ctx.fillText(" meg az 'r' betűt.", 470, 300);
                        }
                        else if(this.outOfLives)
                        {
                            if(!this.isSavingScore)
                            {
                                this.isSavingScore = true;
                                this.finishGame();
                            }
                            this.ctx.drawImage(this.infobg, 0, 0, 640, 480);
                            this.ctx.fillText("Elfogytak az életeid!", 520, 50);
                            this.ctx.fillText("A játék újrakezdéséhez nyomd", 560, 250);
                            this.ctx.fillText(" meg az 'r' betűt.", 470, 300);
                        }
                }
        }
        requestAnimationFrame(this.gameLoop);
    }
}

class Data
{
    constructor(ctx, canvas)
    {
        this.canvas = canvas;
        this.ctx = ctx;
        this.map_1_enemies = [new Fox(800, 251, 1, 54, 30, this.canvas, this.ctx, 120, "fox"), new Fox(2560, 451, 1.5, 54, 30, this.canvas, this.ctx, 120, "fox"), new Fox(3320, 251, 0.5, 54, 30, this.canvas, this.ctx, 60, "fox"), new Fox(2920, 971, 0.5, 54, 30, this.canvas, this.ctx, 120, "fox"), new Fox(2960, 851, 1, 54, 30, this.canvas, this.ctx, 80, "fox"), new Fox(1800, 651, 1, 54, 30, this.canvas, this.ctx, 120, "fox"), new Fox(1720, 131, 1, 54, 30, this.canvas, this.ctx, 120, "fox")];
        this.map_1_pickups = [new PickUp(880, 170, 32, 32, "corn", 100, this.ctx), new PickUp(3400, 250, 32, 32, "corn", 100, this.ctx), new PickUp(2360, 730, 32, 32, "corn", 100, this.ctx), new PickUp(2880, 850, 32, 32, "heal", 200, this.ctx), new PickUp(2360, 850, 32, 32, "heal", 200, this.ctx), new PickUp(1680, 650, 32, 32, "heal", 200, this.ctx), new PickUp(2360, 132, 18, 28, "lives", 1000, this.ctx)];
        this.map_1_deco = new Decoration(1480, 646, this.ctx, "end_table", 42, 36);
    }
}

const motor = new GameEngine();
motor.gameLoop();
