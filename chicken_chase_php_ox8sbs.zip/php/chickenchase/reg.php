<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    require('connect.php');

    $kapcsolat
        ->prepare("INSERT INTO user (username, password, profile_image_index) VALUES (:username, :password, :profile_image_index)")
        ->execute([
            'username' => $_POST["username"],
            'password' => md5($_POST["password"]),
            'profile_image_index' => intval($_POST["profile_image_index"])
        ]);
    
    echo "Sikeres regisztráció";
    header("Location: login.php");
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="src/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="style/reg.css">
    <title>Chicken Chase - Regisztráció</title>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
</head>
<body>
    <h1 id="title">Chicken Chase</h1>
    <div id="reg_div">
        <form method="post" id="regForm">
            <h1>Regisztráció</h1>
            <input type="text" placeholder="Felhasználónév" name="username" id="username" required><br>
            <input type="password" placeholder="Jelszó" name="password" id="password" required><br>
            <div id="profpicDiv">
                <label id="text1" for="profilePicture">Válassz egy profilképet!</label>
                <div id="profilePictureSelection">
                    <img src="src/img/profile_img/profil0.png" style="width: 80px;" class="profile-picture" data-index="0" onclick="selectProfilePicture(0)">
                    <img src="src/img/profile_img/profil1.png" class="profile-picture" data-index="1" onclick="selectProfilePicture(1)">
                    <img src="src/img/profile_img/profil2.png" class="profile-picture" data-index="2" onclick="selectProfilePicture(2)">
                    <img src="src/img/profile_img/profil3.png" class="profile-picture" data-index="3" onclick="selectProfilePicture(3)">
                </div>
                <input type="hidden" id="profilePictureIndex" name="profile_image_index" value="0">
            </div>
            <input type="submit" value="Regisztráció" id="registerButton">
            <div id="logDiv">
                <p>Már van fiókod? <a onclick="window.location.href='login.php'">Bejelentkezés</a></p>
            </div>
            <script>
                function selectProfilePicture(index)
                {
                    const pictures = document.querySelectorAll(".profile-picture");
                    pictures.forEach(pic => pic.style.width = "64px");

                    const selectedPicture = pictures[index];
                    selectedPicture.style.width = "80px";

                    document.getElementById("profilePictureIndex").value = index;
                    console.log(document.getElementById("profilePictureIndex").value);
                }
            </script>
        </form>
    </div>
</body>
</html>