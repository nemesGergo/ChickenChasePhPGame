<?php
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    session_start();

    require('connect.php');
    
    $stmt = $kapcsolat->prepare("SELECT id, username, score, profile_image_index, map FROM user WHERE username = :username AND password = :password");
    $stmt->execute([
        "username" => $_POST["username"],
        "password" => md5($_POST["password"])
    ]);
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if( $user != null ) {
        echo "sikeres bejelentkezés";
        $_SESSION["id"] = $user["id"];
        $_SESSION["username"] = $user["username"];
        $_SESSION["score"] = $user["score"];
        $_SESSION["playerImage"] = $user["profile_image_index"];
        $_SESSION["map"] = $user["map"];
        header("Location: index.php");
    }
    else {
        $error_message = "Hibás felhasználónév vagy jelszó!";
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="src/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="style/login.css">
    <title>Chicken Chase - Bejelentkezés</title>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
</head>
<body>
    <h1 id="title">Chicken Chase</h1>
    <div id="login_div">
        <form method="post" id="loginForm">
            <h1>Bejelentkezés</h1>
            <input type="text" name="username" id="username" placeholder="Felhasználónév" required><br>
            <input type="password" name="password" id="password" placeholder="Jelszó" required><br>
            <input type="submit" value="Bejelentkezés" id="loginButton">
            <div id="regDiv">
                <p>Még nincs fiókod? <a onclick="window.location.href='reg.php'">Regisztráció</a></p>
            </div>
            <?php if (isset($error_message)): ?>
                <div id="wrongLogin">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>

