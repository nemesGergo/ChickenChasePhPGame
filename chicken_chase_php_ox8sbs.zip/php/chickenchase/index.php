<?php
    session_start();
    require("connect.php");
    
    if(!isset($_SESSION["id"]))
    {
        header("Location: login.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="src/favicon.ico" type="image/x-icon">
    <title>Chicken Chase</title>
    <link rel="stylesheet" href="style/main.css">
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
</head>
<body>
    <h1 id="title">Chicken Chase</h1>
    <div id="mainContainer">
        <div id="pauseDiv">
            <p id="pauseText">Szünet</p>
            <button id="p_backToMenu">Vissza a menübe</button>
            <button id="p_backToGame">Bezárás</button>
        </div>
        <div id="profileDiv">
            <img id="profileBackground" src="src/img/menu/profilHatter.png">
            <img id="playerBiggerProfileImage" src="src/img/profile_img/profil<?php echo $_SESSION["playerImage"]; ?>.png">
            <p id="usernameText"><?php echo htmlspecialchars($_SESSION["username"]); ?></p>
            <p id="highScoreText">High Score: <?php echo htmlspecialchars($_SESSION["score"]); ?></p>
            <form action="scripts/logout.php" method="post" id="profileForm">
                <button type="submit" name="action" value="1">Kijelentkezés</button>
            </form>
            <button id="backtomenuB">Vissza</button>
        </div>
        <div id="menuDiv">
            <img id="titleImg" src="src/img/menu/title.png" draggable="false" width="640px" height="86px">
            <button id="newGame">Új játék</button>
            <button id="levelLoad">Pálya választása (Nem elérhető)</button>
            <button id="settingsB">Beállítások (Nem elérhető)</button>
            <button id="profilB"><img id="playerProfileImage" src="src/img/profile_img/profil<?php echo $_SESSION["playerImage"]; ?>.png">Profil</button>
            <p id="creditText">Készítette: Nemes Gergő (OX8SBS)</p>
            
            
            <canvas id="mainMenuCanvas" width="640" height="480"></canvas>
        </div>
        <div id="gameDiv">
            <canvas id="gameCanvas" width="640" height="480"></canvas>
        </div>
    </div>
    <!--<a href="https://github.com/nemesGergo/ChickenChaseGame" target="_blank">GITHUB Link</a>-->
</body>
<script type="module" src="scripts/utils.js"></script>
<script type="module" src="scripts/game.js"></script>
</html>